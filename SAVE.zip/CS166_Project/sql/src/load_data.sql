COPY USR FROM '/tmp/rchen016/CS166_Project/data/USR.csv' DELIMITER ',' CSV;
COPY EDUCATIONAL_DETAILS FROM '/tmp/rchen016/CS166_Project/data/Edu_Det.csv' DELIMITER ',' CSV;
COPY MESSAGE FROM '/tmp/rchen016/CS166_Project/data/Message.csv' DELIMITER ',' CSV;
COPY WORK_EXPR FROM '/tmp/rchen016/CS166_Project/data/Work_Ex.csv' DELIMITER ',' CSV;
COPY CONNECTION_USR FROM '/tmp/rchen016/CS166_Project/data/Connection.csv' DELIMITER ',' CSV;

