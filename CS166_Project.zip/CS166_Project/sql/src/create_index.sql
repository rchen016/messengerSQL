CREATE INDEX password ON USR
USING btree(password);

